Line Alphat JS

# require node >= v8.x.x
check your nodejs version
`node -v`
[upgrade nodejs](https://google.com/)


How to run ?
------
- `git clone https://github.com/alfathdirk/LineAlphatJS.git`
- `cd LineAlphatJS && npm install`
- `npm start`


Still work :construction_worker:
----
**TODO** features
- Implement All 
- Improve logic

Author
------
[@alfathdirk](https://instagram.com/alfathdirk)
